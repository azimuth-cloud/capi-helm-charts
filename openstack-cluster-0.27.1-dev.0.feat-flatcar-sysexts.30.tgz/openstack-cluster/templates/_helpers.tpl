{{/*
Create a cluster name. The name of the cluster is just the release name.
*/}}
{{- define "openstack-cluster.clusterName" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Create a name for a cluster component.
*/}}
{{- define "openstack-cluster.componentName" -}}
{{- $ctx := index . 0 -}}
{{- $componentName := index . 1 -}}
{{- printf "%s-%s" $ctx.Release.Name $componentName | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "openstack-cluster.chart" -}}
{{-
  printf "%s-%s" .Chart.Name .Chart.Version |
    replace "+" "_" |
    trunc 63 |
    trimSuffix "-" |
    trimSuffix "." |
    trimSuffix "_"
}}
{{- end }}

{{/*
Common labels
*/}}
{{- define "openstack-cluster.commonLabels" -}}
helm.sh/chart: {{ include "openstack-cluster.chart" . }}
{{ .Values.projectPrefix }}/managed-by: {{ .Release.Service }}
{{ .Values.projectPrefix }}/infrastructure-provider: openstack
{{- end -}}

{{/*
Selector labels for cluster-level resources
*/}}
{{- define "openstack-cluster.selectorLabels" -}}
{{ .Values.projectPrefix }}/cluster: {{ include "openstack-cluster.clusterName" . }}
{{- end -}}

{{/*
Labels for cluster-level resources
*/}}
{{- define "openstack-cluster.labels" -}}
{{ include "openstack-cluster.commonLabels" . }}
{{ include "openstack-cluster.selectorLabels" . }}
{{- end -}}

{{/*
Selector labels for component-level resources
*/}}
{{- define "openstack-cluster.componentSelectorLabels" -}}
{{- $ctx := index . 0 -}}
{{- $componentName := index . 1 -}}
{{ include "openstack-cluster.selectorLabels" $ctx }}
{{ $ctx.Values.projectPrefix }}/component: {{ $componentName }}
{{- end -}}

{{/*
Labels for component-level resources
*/}}
{{- define "openstack-cluster.componentLabels" -}}
{{ include "openstack-cluster.commonLabels" (index . 0) }}
{{ include "openstack-cluster.componentSelectorLabels" . }}
{{- end -}}

{{/*
Name of the secret containing the cloud credentials.
*/}}
{{- define "openstack-cluster.cloudCredentialsSecretName" -}}
{{- if .Values.cloudCredentialsSecretName -}}
{{- .Values.cloudCredentialsSecretName -}}
{{- else -}}
{{ include "openstack-cluster.componentName" (list . "cloud-credentials") -}}
{{- end -}}
{{- end -}}

{{/*
Template that merges two variables with the latter taking precedence and outputs the result as YAML.
Lists are merged by concatenating them rather than overwriting.
*/}}
{{- define "openstack-cluster.mergeConcat" -}}
{{- $left := index . 0 }}
{{- $right := index . 1 }}
{{- if kindIs (kindOf list) $left }}
{{- if kindIs (kindOf list) $right }}
{{ concat $left $right | toYaml }}
{{- else }}
{{ default $left $right | toYaml }}
{{- end }}
{{- else if kindIs (kindOf dict) $left }}
{{- if kindIs (kindOf dict) $right }}
{{- range $key := concat (keys $left) (keys $right) | uniq }}
{{- if and (hasKey $left $key) (hasKey $right $key) }}
{{- $merged := include "openstack-cluster.mergeConcat" (list (index $left $key) (index $right $key)) }}
{{ $key }}: {{ $merged | nindent 2 }}
{{- else if hasKey $left $key }}
{{ index $left $key | dict $key | toYaml }}
{{- else }}
{{ index $right $key | dict $key | toYaml }}
{{- end }}
{{- end }}
{{- else }}
{{ default $left $right | toYaml }}
{{- end }}
{{- else }}
{{ default $left $right | toYaml }}
{{- end }}
{{- end }}

{{/*
Applies a list of templates to an input object sequentially.
*/}}
{{- define "openstack-cluster.mergeConcatMany" -}}
{{- $obj := first . }}
{{- range $overrides := rest . }}
{{- $obj = include "openstack-cluster.mergeConcat" (list $obj $overrides) | fromYaml }}
{{- end }}
{{- toYaml $obj }}
{{- end }}

{{/*
Outputs the node registration object for setting node labels.
*/}}
{{- define "openstack-cluster.nodeRegistration.nodeLabels" -}}
nodeRegistration:
  kubeletExtraArgs:
    node-labels: "{{ range $i, $k := (keys . | sortAlpha) }}{{ if ne $i 0 }},{{ end }}{{ $k }}={{ index $ $k }}{{ end }}"
{{- end }}

{{/*
Converts the tags in a Neutron filter when required.
*/}}
{{- define "openstack-cluster.convert.tags" -}}
{{- if kindIs "string" . -}}
{{- splitList "," . | toYaml }}
{{- else -}}
{{- toYaml . }}
{{- end }}
{{- end }}

{{/*
Converts a v1alpha7 Neutron ports filter to a v1beta1 filter.
*/}}
{{- define "openstack-cluster.convert.neutronPortsFilter" -}}
{{- $ports := list -}}
{{- range $p := . -}}
{{- if $p.network -}}
{{- with $p.network -}}
{{- if not ( hasKey . "filter" ) -}}
{{- $portNetwork := include "openstack-cluster.convert.neutronFilter" . | fromYaml -}}
{{- $p := set $p "network" $portNetwork -}}
{{- end -}}
{{- $ports = append $ports $p -}}
{{- end -}}
{{- else -}}
{{- $ports = append $ports $p -}}
{{- end -}}
{{- end -}}
{{- toYaml $ports }}
{{- end }}

{{/*
Converts a v1alpha7 Neutron filter to a v1beta1 filter.
*/}}
{{- define "openstack-cluster.convert.neutronFilter" -}}
{{- if hasKey . "id" -}}
id: {{ .id }}
{{- else -}}
filter:
  {{- with omit . "tags" "tagsAny" "notTags" "notTagsAny" }}
  {{- toYaml . | nindent 2 }}
  {{- end }}
  {{- with .tags }}
  tags: {{ include "openstack-cluster.convert.tags" . | nindent 4 }}
  {{- end }}
  {{- with .tagsAny }}
  tagsAny: {{ include "openstack-cluster.convert.tags" . | nindent 4 }}
  {{- end }}
  {{- with .notTags }}
  notTags: {{ include "openstack-cluster.convert.tags" . | nindent 4 }}
  {{- end }}
  {{- with .notTagsAny }}
  notTagsAny: {{ include "openstack-cluster.convert.tags" . | nindent 4 }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Outputs the content for a containerd registry file containing mirror configuration.
*/}}
{{- define "openstack-cluster.registryFile" -}}
{{- $registry := index . 0 -}}
{{- $registrySpec := index . 1 -}}
{{-
  $defaultUpstream :=
    eq $registry "docker.io" |
    ternary "registry-1.docker.io" $registry |
    printf "https://%s"
-}}
{{-
  $upstream :=
    kindIs "map" $registrySpec |
    ternary $registrySpec dict |
    dig "upstream" $defaultUpstream
-}}
{{-
  $mirrors :=
    kindIs "map" $registrySpec |
    ternary $registrySpec (dict "mirrors" $registrySpec) |
    dig "mirrors" list
-}}
{{- with $upstream }}
server = "{{ . }}"
{{- end }}
{{- range $mirror := $mirrors }}
{{-
  $url :=
    kindIs "map" $mirror |
    ternary $mirror (dict "url" $mirror) |
    dig "url" "" |
    required "unable to determine mirror url"
}}
{{-
  $capabilities :=
    kindIs "map" $mirror |
    ternary $mirror (dict "capabilities" list) |
    dig "capabilities" list |
    default (list "pull" "resolve")
}}
{{-
  $skipVerify :=
    kindIs "map" $mirror |
    ternary $mirror (dict "skipVerify" false) |
    dig "skipVerify" false
}}
{{-
  $overridePath :=
    kindIs "map" $mirror |
    ternary $mirror (dict "overridePath" true) |
    dig "overridePath" true
}}
[host."{{ $url }}"]
capabilities = [{{ range $i, $cap := $capabilities }}{{ if gt $i 0 }}, {{ end }}"{{ . }}"{{ end }}]
skip_verify = {{ ternary "true" "false" $skipVerify }}
override_path = {{ ternary "true" "false" $overridePath }}
{{- end }}
{{- end }}

{{/*
Produces the kubeadmConfigSpec required to configure containerd.
*/}}
{{- define "openstack-cluster.kubeadmConfigSpec.containerd" -}}
files:
  - path: /etc/containerd/conf.d/.keepdir
    content: |
      # This file is created by the capi-helm-chart to ensure that its parent directory exists
    owner: root:root
    permissions: "0644"
  - path: /etc/containerd/certs.d/.keepdir
    content: |
      # This file is created by the capi-helm-chart to ensure that its parent directory exists
    owner: root:root
    permissions: "0644"
{{- with .Values.registryMirrors }}
{{- range $registry, $registrySpec := . }}
  - path: /etc/containerd/certs.d/{{ $registry }}/hosts.toml
    content: |
      {{- include "openstack-cluster.registryFile" (list $registry $registrySpec) | nindent 6 }}
    owner: root:root
    permissions: "0644"
{{- end }}
{{- end }}
{{- if .Values.registryAuth }}
  - path: /etc/containerd/conf.d/auth.toml
    contentFrom:
      secret:
        name: {{ include "openstack-cluster.componentName" (list . "containerd-auth") }}
        key: "auth.toml"
    owner: root:root
    permissions: "0644"
{{- end }}
{{- if and (ne .Values.osDistro "flatcar") (ne .Values.osDistro "flatcar-sysext") }}
preKubeadmCommands:
  - |
      /usr/bin/bash -s <<EOF
      grep -q '\[plugins."io.containerd.grpc.v1.cri".registry\]' /etc/containerd/config.toml && exit
      cat <<CONTENT >> /etc/containerd/config.toml
      [plugins."io.containerd.grpc.v1.cri".registry]
        config_path = "/etc/containerd/certs.d"
      CONTENT
      systemctl restart containerd
      EOF
{{- end }}
{{- end }}

{{/*
Produces the kubeadmConfigSpec required to configure additional trusted CAs for cluster nodes,
e.g. for private registries.
*/}}
{{- define "openstack-cluster.kubeadmConfigSpec.trustedCAs" -}}
{{- if and (ne .Values.osDistro "flatcar") (ne .Values.osDistro "flatcar-sysext") }}
{{- with .Values.trustedCAs }}
files:
  {{- range $name, $certificate := . }}
  - path: /usr/local/share/ca-certificates/{{ $name }}.crt
    content: |
      {{- nindent 6 $certificate }}
    owner: root:root
    permissions: "0644"
  {{- end }}
preKubeadmCommands:
  - update-ca-certificates
{{- end }}
{{- end }}
{{- end }}

{{/*
Produces the kubeadmConfigSpec required to install additional packages.
*/}}
{{- define "openstack-cluster.kubeadmConfigSpec.additionalPackages" -}}
{{- if and (ne .Values.osDistro "flatcar") (ne .Values.osDistro "flatcar-sysext") }}
{{- with .Values.additionalPackages }}
preKubeadmCommands:
  - apt update -y
  - apt install -y {{ join " " . }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Produces the spec for a KubeadmConfig object.
*/}}
{{- define "openstack-cluster.kubeadmConfigSpec" -}}
{{- $ctx := index . 0 }}
{{- $kubeadmConfigSpec := index . 1 }}
{{-
  list
    (include "openstack-cluster.kubeadmConfigSpec.trustedCAs" $ctx | fromYaml)
    (include "openstack-cluster.kubeadmConfigSpec.containerd" $ctx | fromYaml)
    (include "openstack-cluster.kubeadmConfigSpec.additionalPackages" $ctx | fromYaml)
    $kubeadmConfigSpec |
  include "openstack-cluster.mergeConcatMany"
}}
{{- end }}

{{/*
Produces the spec for an Ignition based OS specific KubeadmConfig object conditional on osDistro set to "flatcar".
${COREOS_OPENSTACK_HOSTNAME} is set by coreos-metadata (EnvironmentFile=/run/metadata/flatcar),
exported in preKubeadmCommands, then substituted into /etc/kubeadm.yml by envsubst before kubeadm runs.
*/}}
{{- define "openstack-cluster.flatcarKubeadmConfigSpec" -}}
initConfiguration:
  nodeRegistration:
    name: ${COREOS_OPENSTACK_HOSTNAME}
joinConfiguration:
  nodeRegistration:
    name: ${COREOS_OPENSTACK_HOSTNAME}
preKubeadmCommands:
  - export COREOS_OPENSTACK_HOSTNAME=${COREOS_OPENSTACK_HOSTNAME%.*}
  - envsubst < /etc/kubeadm.yml > /etc/kubeadm.yml.tmp
  - mv /etc/kubeadm.yml.tmp /etc/kubeadm.yml
format: ignition
ignition:
  containerLinuxConfig:
    additionalConfig: |
      systemd:
        units:
        # this service must not run if no key has been provided by openstack, it retries
        # forever causing a mount error in the kernel log.
        # sshkeys.service (baked into flatcar) starts this unit directly via `systemctl start`
        # whenever it isn't already masked, regardless of enabled/disabled, so when there is
        # no key the service must be masked.
        - name: coreos-metadata-sshkeys@core.service
          {{- if .Values.machineSSHKeyName }}
          enabled: true
          {{- else }}
          mask: true
          {{- end }}
        - name: kubeadm.service
          enabled: true
          dropins:
          - name: 10-flatcar.conf
            contents: |
              [Unit]
              Requires=containerd.service coreos-metadata.service
              After=containerd.service coreos-metadata.service
              [Service]
              EnvironmentFile=/run/metadata/flatcar
{{- end }}

{{/*
Produces the spec for an Ignition based OS specific KubeadmConfig object, dispatching to the
osDistro-specific helper.
The flatcar-sysext helpers live in _helpers.flatcar-sysext.tpl.
*/}}
{{- define "openstack-cluster.osDistroKubeadmConfigSpec" }}
{{- $ctx := index . 0 }}
{{- $sysexts := index . 1 }}
{{- $osDistro := $ctx.Values.osDistro }}
{{- if eq $osDistro "flatcar" }}
{{- include "openstack-cluster.flatcarKubeadmConfigSpec" $ctx }}
{{- else if eq $osDistro "flatcar-sysext" }}
{{- include "openstack-cluster.flatcarSysextKubeadmConfigSpec" (list $ctx $sysexts) }}
{{- end }}
{{- end }}

{{/*
Create folders necessary for webhook integration.
*/}}
{{- define "openstack-cluster.webhookPatches" }}
{{- $authWebhook := .Values.authWebhook }}
  preKubeadmCommands:
    - mkdir -p /etc/kubernetes/webhooks
    - mkdir -p /etc/kubernetes/patches
{{- if eq $authWebhook "k8s-keystone-auth" }}
    - mkdir -p /etc/kubernetes/keystone-auth
  postKubeadmCommands:
    - cp /etc/kubernetes/manifests/kube-apiserver.yaml /etc/kubernetes/keystone-auth/kube-apiserver.yaml
    - kubectl kustomize /etc/kubernetes/keystone-auth -o /etc/kubernetes/manifests/kube-apiserver.yaml
{{- end }}
{{- end }}

{{/*
Supplement kubeadmConfig with apiServer config and webhook patches as needed. Authentication
webhooks and policies for audit logging can be added here.
*/}}
{{- define "openstack-cluster.patchConfigSpec" -}}
{{- $ctx := index . 0 }}
{{- $authWebhook := $ctx.Values.authWebhook }}
  clusterConfiguration:
    apiServer:
      extraArgs:
        v: {{ $ctx.Values.apiServer.logLevel | quote }}
{{- if ne $authWebhook "none" }}
{{- if eq $authWebhook "azimuth-authorization-webhook" }}
        authorization-config: /etc/kubernetes/webhooks/authorization_config.yaml
{{/*
Add else if blocks with other webhooks and apiServer arguments (i.e. audit logging)
in future
*/}}
{{- end }}
  initConfiguration:
    patches:
      directory: /etc/kubernetes/patches
  joinConfiguration:
    patches:
      directory: /etc/kubernetes/patches
{{- include "openstack-cluster.webhookPatches" $ctx }}
{{- if eq $authWebhook "k8s-keystone-auth" }}
{{- include "openstack-cluster.k8sKeystoneAuthWebhook" $ctx }}
{{- else if eq $authWebhook "azimuth-authorization-webhook" }}
{{- include "openstack-cluster.azimuthAuthorizationWebhook" $ctx }}
{{/*
Add else if blocks with other webhooks or policy files in future.
*/}}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create and mount a directory for webhooks
*/}}
{{- define "openstack-cluster.webhookMountDirectoryFile"}}
    - path: /etc/kubernetes/patches/kube-apiserver0+strategic.yaml
      permissions: "0644"
      owner: root:root
      content: |
        spec:
          containers:
          -  name: kube-apiserver
             volumeMounts:
             - mountPath: /etc/kubernetes/webhooks
               name: kube-webhooks
               readOnly: true
          volumes:
          - hostPath:
              path: /etc/kubernetes/webhooks
              type: DirectoryOrCreate
            name: kube-webhooks
{{- end }}

{{/*
Produces integration for k8s-keystone-auth webhook on apiserver
*/}}
{{- define "openstack-cluster.k8sKeystoneAuthWebhook" }}
  files:
{{- include "openstack-cluster.webhookMountDirectoryFile" . }}
    - path: /etc/kubernetes/keystone-auth/kustomization.yml
      permissions: "0644"
      owner: root:root
      content: |
        resources:
        - kube-apiserver.yaml
        patches:
        - patch: |-
            - op: add
              path: /spec/containers/0/command/-
              value: --authentication-token-webhook-config-file=/etc/kubernetes/webhooks/keystone_webhook_config.yaml
            - op: add
              path: /spec/containers/0/command/-
              value: --authorization-webhook-config-file=/etc/kubernetes/webhooks/keystone_webhook_config.yaml
            - op: add
              path: /spec/containers/0/command/-
              value: --authorization-mode=Webhook
          target:
            kind: Pod
    - path: /etc/kubernetes/webhooks/keystone_webhook_config.yaml
      content: |
        ---
        apiVersion: v1
        kind: Config
        preferences: {}
        clusters:
          - cluster:
              insecure-skip-tls-verify: true
              server: https://127.0.0.1:8443/webhook
            name: webhook
        users:
          - name: webhook
        contexts:
          - context:
              cluster: webhook
              user: webhook
            name: webhook
        current-context: webhook
      owner: root:root
      permissions: "0644"
{{- end }}

{{/*
Produces integration for azimuth_authorization_webhook on apiserver
*/}}
{{- define "openstack-cluster.azimuthAuthorizationWebhook" }}
  files:
{{- include "openstack-cluster.webhookMountDirectoryFile" . }}
    {{- if $.Values.azimuthAuthorizationWebhook.tls.enabled }}
    - path: /etc/kubernetes/webhooks/ca.pem
      content: {{ $.Values.azimuthAuthorizationWebhook.tls.cert | toYaml | nindent 12 }}
    {{- end }}
    - path: /etc/kubernetes/webhooks/azimuth_authorization_webhook_config.yaml
      content: |
        ---
        apiVersion: v1
        kind: Config
        preferences: {}
        clusters:
          - cluster:
              {{- if $.Values.azimuthAuthorizationWebhook.tls.enabled }}
              certificate-authority: /etc/kubernetes/webhooks/ca.pem
              {{- else }}
              insecure-skip-tls-verify: true
              {{- end }}
              server: {{ $.Values.azimuthAuthorizationWebhook.server }}
            name: webhook
        users:
          - name: webhook
        contexts:
          - context:
              cluster: webhook
              user: webhook
            name: webhook
        current-context: webhook
      owner: root:root
      permissions: "0644"
    - path: /etc/kubernetes/webhooks/authorization_config.yaml
      content: |
        ---
        apiVersion: apiserver.config.k8s.io/v1
        kind: AuthorizationConfiguration
        authorizers:
          - type: Webhook
            name: webhook
            webhook:
              timeout: {{ $.Values.azimuthAuthorizationWebhook.timeout }}
              subjectAccessReviewVersion: {{ $.Values.azimuthAuthorizationWebhook.webhookVersion }}
              matchConditionSubjectAccessReviewVersion: {{ $.Values.azimuthAuthorizationWebhook.webhookVersion }}
              failurePolicy: {{ $.Values.azimuthAuthorizationWebhook.failurePolicy }}
              connectionInfo:
                type: KubeConfigFile
                kubeConfigFile: /etc/kubernetes/webhooks/azimuth_authorization_webhook_config.yaml
              matchConditions:
                {{- $quotedNSList := list }}
                {{- range $.Values.azimuthAuthorizationWebhook.filteredNamespaces }}
                {{- $quotedNSList = append $quotedNSList (quote .) }}
                {{- end }}
                - expression: has(request.resourceAttributes) && (!has(request.resourceAttributes.namespace) || request.resourceAttributes.namespace == "" || request.resourceAttributes.namespace in [{{ join "," $quotedNSList }}])
              {{- range $.Values.azimuthAuthorizationWebhook.extraPreFilters }}
                - expression: {{ . }}
              {{- end }}
          {{- range $.Values.azimuthAuthorizationWebhook.additionalAuthorizers }}
          - type: {{ .type }}
            name: {{ .name }}
          {{- end }}
{{- end }}

{{/*
Return a list of security groups to apply to worker nodes when
OVN is the apiserver loadbalancer provider
*/}}
{{- define "openstack-cluster.workerNodesSecurityGroupRulesOVN" }}
workerNodesSecurityGroupRules:
  - name: Worker nodePort TCP
    remoteIPPrefix: 0.0.0.0/0
    protocol: tcp
    direction: ingress
    etherType: IPv4
    portRangeMin: 30000
    portRangeMax: 32767
  - name: Worker nodePort UDP
    protocol: udp
    remoteIPPrefix: 0.0.0.0/0
    direction: ingress
    etherType: IPv4
    portRangeMin: 30000
    portRangeMax: 32767
{{- end }}

{{/*
Creates a list of security group rules to apply to worker nodes
*/}}
{{- define "openstack-cluster.workerNodesSecurityGroupRules" }}
{{- $msecgroups := index . 0 }}
{{- $ovnapiserver := index . 1 }}
{{- if $ovnapiserver }}
{{- $ovn := include "openstack-cluster.workerNodesSecurityGroupRulesOVN" $ovnapiserver | fromYaml }}
{{- concat $msecgroups.workerNodesSecurityGroupRules $ovn.workerNodesSecurityGroupRules | uniq | toYaml }}
{{- else }}
{{- toYaml $msecgroups.workerNodesSecurityGroupRules }}
{{- end }}
{{- end }}
